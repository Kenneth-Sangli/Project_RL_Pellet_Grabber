using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using Unity.MLAgents.Actuators;

public class AgentController : Agent
{
    [SerializeField] private Transform target;
    [SerializeField] private float moveSpeed = 4f;
    private Rigidbody rb;


    public override void Initialize()
    {
        rb = GetComponent<Rigidbody>();
    }

    public override void OnEpisodeBegin()
    {
        // Move the transform to a new position
        //Agent's position
        transform.localPosition = new Vector3(Random.Range(-4f,4f),0.3f, Random.Range(-4f, 4f));
        //Target's position (pellet)
        target.localPosition = new Vector3(Random.Range(-4f, 4f), 0.3f, Random.Range(-4f, 4f));
    }
    
    public override void CollectObservations(VectorSensor sensor)
    {
        // Add the agent's position
        sensor.AddObservation(transform.localPosition);
        //sensor.AddObservation(target.localPosition);
    }
    
    public override void OnActionReceived(ActionBuffers actions)
    {
        // Get the action values
        float moveRotate = actions.ContinuousActions[0];
        float moveForward = actions.ContinuousActions[1];

        rb.MovePosition(transform.position + transform.forward * moveForward * moveSpeed * Time.fixedDeltaTime);
        transform.Rotate(0f, moveRotate* moveSpeed, 0f, Space.Self);

        /*Vector3 velocity = new Vector3(moveX, 0f, moveZ);
        velocity= velocity.normalized * Time.deltaTime * moveSpeed;

        // Move the agent
        transform.localPosition += velocity;
*/
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        ActionSegment<float> continuousActions = actionsOut.ContinuousActions;
        continuousActions[0] = Input.GetAxisRaw("Horizontal");
        continuousActions[1] = Input.GetAxisRaw("Vertical");
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag=="Pellet")
        {
            AddReward(5f);
            EndEpisode();
        }
        if (other.gameObject.tag=="Wall")
        {
            AddReward(-1f);
            EndEpisode();
        }
    }
}
