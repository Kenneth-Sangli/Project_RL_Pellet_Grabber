# Pellet Grabber - Projet ML-Agents Unity

Ce projet utilise Unity ML-Agents pour entraîner un agent à collecter des "pellets" dans un environnement délimité par des murs. L'agent est récompensé lorsqu'il atteint un pellet et pénalisé s'il touche un mur.

## Structure du projet

- **Assets/** : Contient tous les assets Unity.
  - **Scenes/** : Contient les scènes Unity pour l'entraînement (`TrainingScene.unity`) et l'inférence (`InferenceScene.unity`).
  - **Scripts/** : Contient les scripts C# (comme `AgentController.cs`).
  - **Prefabs/** : Contient les prefabs Unity (comme `Agent.prefab`, `Walls.prefab`, etc.).
  - **Materials/** : Contient les matériaux utilisés dans les scènes.
  - **ML-Agents/** : Contient les fichiers spécifiques à ML-Agents.
    - **Config/** : Contient les fichiers de configuration pour l'entraînement (par exemple, `trainer_config.yaml`).
    - **Models/** : Contient les modèles entraînés (par exemple, `PelletGrabberModel.onnx`).
- **Packages/** : Contient le fichier `manifest.json` listant les dépendances Unity.
- **ProjectSettings/** : Contient les paramètres du projet Unity.

PelletGrabberProject/
├── Assets/                     # Contient tous les assets Unity
│   ├── Scenes/                # Scènes Unity (entraînement)
│   │   ├── TrainingScene.unity
│   ├── Scripts/               # Scripts C# (comme AgentController.cs)
│   │   └── AgentController.cs
│   ├── Prefabs/               # Prefabs Unity (comme Agent.prefab, Walls.prefab, etc.)
│   │   ├── Agent.prefab
│   │   └── Env.prefab
│   ├── Materials/             # Matériaux Unity utilisés
│   └── ML-Agents/             # Fichiers spécifiques à ML-Agents
│       ├── Config/            # Fichiers de configuration pour l'entraînement (YAML)
│       │   └── trainer_config.yaml
└── Models/            # Modèles entraînés (.onnx)
│           └── Agent Controller.onnx (version finale entrainée)
│           └── Moremovements.onnx (version sans les Rayons)
│           └── SideBrain.onnx (version béta test pour voir si ça marche)
├── Packages/                  # Fichiers de gestion des packages Unity
│   └── manifest.json
├── ProjectSettings/           # Paramètres du projet Unity
├── README.md                  # Fichier README en markdown
└── PelletGrabberProject.zip   # Fichier ZIP final pour le rendu

## Prérequis

Pour exécuter ce projet, vous aurez besoin de :

- Unity 2022.3 ou une version ultérieure.
-Un environnement de développement Python 3.10+ avec le package `mlagents` installé (`pip install mlagents`).
- Le package Unity ML-Agents (installé via le `manifest.json` dans `Packages/`).
- Python 3.10+ avec le package `mlagents` installé (`pip install mlagents`).

## Installation

1. Clonez ou décompressez ce projet dans un dossier local.
2. Ouvrez le projet dans Unity en sélectionnant le dossier `PelletGrabberProject/`.
3. Assurez-vous que le package ML-Agents est installé (vérifiez `Packages/manifest.json`).
4. Pour entraîner l'agent, vous devrez également installer `mlagents` via pip :
   ```bash
   pip install mlagents
   ```
5. Vous êtes prêt à commencer !

## Entraînement

Pour entraîner l'agent :

1. Ouvrez la scène `SampleScene` dans Unity.
2. Depuis un terminal, naviguez vers le dossier contenant `config.yaml`.
3. Exécutez la commande suivante pour lancer l'entraînement :
   ```bash
   mlagents-learn config.yaml --run-id=PelletGrabberTraining
    ```
4. Vous pouvez suivre la progression de l'entraînement dans TensorBoard :
   ```bash
   tensorboard --logdir results
   ```
5. Une fois l'entraînement terminé, vous pouvez exporter le modèle entraîné en utilisant le script Python fourni :
   ```bash
    python export_model.py --run-id=PelletGrabberTraining
    ```
6. Le modèle exporté sera enregistré dans `Assets/ML-Agents/Models/`.

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

```
NB: Tout fonctionnait bien dans le dossier mais en voulant pour le rendu modifier la structure du dossier, j'ai rencontré des problèmes de compilation et de lancement ce qui fait que désormais les préfabs ne fonctionnent plus car ils disent qu'ils manquent un script qui est pourtant présent donc pour pouvoir lancer le jeu il faut lancer le Env_Final de l scène ou le Env(1) en mettant comme modèle entrainé "Agent Controller" et en ayant un bon environnement fonctionnel.
```

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////